//
//  SnipApp.swift
//  Snip
//
//  Created by You on [Date].
//

import SwiftUI
import AppKit

// Global function to check and cache accessibility permission.
func recheckAccessibilityPermission() -> Bool {
    let options = [kAXTrustedCheckOptionPrompt.takeRetainedValue() as String: true] as CFDictionary
    let trusted = AXIsProcessTrustedWithOptions(options)
    UserDefaults.standard.set(trusted, forKey: "hasCheckedAccessibilityPermission")
    return trusted
}

@main
struct SnipApp: App {
    // Use an NSApplicationDelegate to manage the status item.
    @NSApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    
    init() {
        // Set up the Application Support folder.
        AppFileManager.shared.setupAppSupportFolder()
    }
    
    var body: some Scene {
        // We’re not using a standard window—our UI is shown in the status bar popover.
        Settings {
            EmptyView()
        }
    }
}

class AppDelegate: NSObject, NSApplicationDelegate {
    var statusBarItem: NSStatusItem?
    var popover: NSPopover?
    
    func applicationDidFinishLaunching(_ notification: Notification) {
        // Check and cache the accessibility permission once.
        let hasChecked = UserDefaults.standard.bool(forKey: "hasCheckedAccessibilityPermission")
        if !hasChecked {
            _ = recheckAccessibilityPermission()
        }
        
        // Hide the dock icon so the app appears only in the status bar.
        NSApp.setActivationPolicy(.accessory)
        
        setupStatusBarItem()
    }
    
    func applicationWillTerminate(_ notification: Notification) {
        if let statusBarItem = statusBarItem {
            NSStatusBar.system.removeStatusItem(statusBarItem)
        }
    }
    
    private func setupStatusBarItem() {
        statusBarItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
        
        if let button = statusBarItem?.button {
            // Replace with your custom icon if desired:
            button.image = NSImage(systemSymbolName: "note.text", accessibilityDescription: "Snip Notes")
            // For a custom asset from Assets.xcassets, use:
            // button.image = NSImage(named: "MyCustomIcon")
            // button.image?.isTemplate = true
            button.action = #selector(togglePopover)
        }
        
        let popover = NSPopover()
        popover.contentViewController = NSHostingController(rootView: ContentView())
        popover.behavior = .transient
        popover.contentSize = NSSize(width: 650, height: 500)
        
        self.popover = popover
    }
    
    @objc func togglePopover() {
        guard let button = statusBarItem?.button, let popover = self.popover else { return }
        if popover.isShown {
            popover.performClose(nil)
        } else {
            popover.show(relativeTo: button.bounds, of: button, preferredEdge: .minY)
        }
    }
}
