//
//  ContentView.swift
//  Snip
//
//  Created by You on [Date].
//

import SwiftUI

// MARK: - Data Models

struct Note: Codable, Identifiable, Equatable {
    let id: UUID
    var content: String
    var name: String
    var isExpanded: Bool = true    // Persisted state for collapse/expand
    
    init(id: UUID = UUID(), content: String, name: String? = nil, isExpanded: Bool = true) {
        self.id = id
        self.content = content
        self.name = name ?? "Note \(UUID().uuidString.prefix(4))"
        self.isExpanded = isExpanded
    }
}

struct Tab: Codable, Identifiable, Equatable {
    let id: UUID
    var name: String
    var notes: [Note]
    
    init(id: UUID = UUID(), name: String, notes: [Note] = []) {
        self.id = id
        self.name = name
        self.notes = notes
    }
}

struct Category: Codable, Identifiable, Equatable {
    let id: UUID
    var name: String
    var tabs: [Tab]
    
    init(id: UUID = UUID(), name: String, tabs: [Tab] = [Tab(name: "General")]) {
        self.id = id
        self.name = name
        self.tabs = tabs
    }
}

// MARK: - Main ContentView

struct ContentView: View {
    @State private var categories: [Category] = {
        if let loaded = AppFileManager.shared.loadCategories() {
            return loaded
        }
        return [Category(name: "General")]
    }()
    
    @State private var selectedCategory: UUID? = nil
    @State private var selectedTab: UUID? = nil
    
    @State private var newCategoryName: String = ""
    @State private var isAddingCategory: Bool = false
    
    @State private var newTabName: String = ""
    @State private var isAddingTab: Bool = false
    
    // Start with no directories by default.
    @State private var directories: [URL] = []
    @State private var isAddingDirectory: Bool = false
    
    // State for showing the Settings sheet.
    @State private var isShowingSettings: Bool = false
    
    var currentTabIndex: Int {
        guard let categoryIndex = categories.firstIndex(where: { $0.id == selectedCategory }),
              let tabIndex = categories[categoryIndex].tabs.firstIndex(where: { $0.id == selectedTab })
        else { return 0 }
        return tabIndex
    }
    
    var body: some View {
        ZStack(alignment: .topTrailing) {
            HStack(spacing: 0) {
                SidebarView(categories: $categories,
                            selectedCategory: $selectedCategory,
                            directories: $directories,
                            isAddingDirectory: $isAddingDirectory,
                            isAddingCategory: $isAddingCategory,
                            newCategoryName: $newCategoryName,
                            deleteCategory: deleteCategory,
                            saveCategories: saveCategories)
                
                MainContentView(categories: $categories,
                                selectedCategory: $selectedCategory,
                                selectedTab: $selectedTab,
                                currentTabIndex: currentTabIndex,
                                isAddingTab: $isAddingTab,
                                newTabName: $newTabName)
            }
            .frame(minWidth: 650, minHeight: 400)
            .onChange(of: categories) { _ in
                saveCategories()
            }
            .sheet(isPresented: $isAddingDirectory) {
                DirectoryPicker(isPresented: $isAddingDirectory, directories: $directories)
            }
            .onAppear {
                // Set initial selection if not already selected.
                if let firstCategory = categories.first {
                    selectedCategory = firstCategory.id
                    selectedTab = firstCategory.tabs.first?.id
                }
            }
            
            // Settings button in the top–right corner.
            Button(action: {
                isShowingSettings = true
            }) {
                Image(systemName: "gear")
                    .padding()
            }
            .buttonStyle(PlainButtonStyle())
        }
        .sheet(isPresented: $isShowingSettings) {
            SettingsView()
        }
    }
    
    // MARK: - Helper Functions
    
    private func saveCategories() {
        do {
            try AppFileManager.shared.saveCategories(categories)
        } catch {
            print("Error saving categories: \(error)")
        }
    }
    
    private func deleteCategory() {
        if let categoryIndex = categories.firstIndex(where: { $0.id == selectedCategory }) {
            categories.remove(at: categoryIndex)
            selectedCategory = categories.first?.id
            selectedTab = categories.first?.tabs.first?.id
            saveCategories()
        }
    }
}

// MARK: - Sidebar View

struct SidebarView: View {
    @Binding var categories: [Category]
    @Binding var selectedCategory: UUID?
    @Binding var directories: [URL]
    @Binding var isAddingDirectory: Bool
    @Binding var isAddingCategory: Bool
    @Binding var newCategoryName: String
    
    var deleteCategory: () -> Void
    var saveCategories: () -> Void
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            // Top section: Directories label and launcher
            Text("Directories")
                .font(.headline)
                .padding(.horizontal)
                .padding(.top, 8)
            
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 10) {
                    ForEach(directories, id: \.self) { directory in
                        Button(action: {
                            NSWorkspace.shared.open(directory)
                        }) {
                            Image(systemName: "folder")
                                .resizable()
                                .frame(width: 16, height: 16)
                        }
                        .contextMenu {
                            Button(action: {
                                directories.removeAll { $0 == directory }
                            }) {
                                Label("Delete", systemImage: "trash")
                            }
                        }
                    }
                    
                    Button(action: { isAddingDirectory = true }) {
                        Image(systemName: "plus.circle")
                            .resizable()
                            .frame(width: 16, height: 16)
                            .foregroundColor(.blue)
                    }
                }
                .padding(.horizontal)
            }
            .padding(.vertical, 8)
            .background(Color.gray.opacity(0.05))
            .cornerRadius(10)
            
            // Second section: Categories label and list.
            Text("Categories")
                .font(.headline)
                .padding(.horizontal)
            
            // Use bindings to allow inline editing of category names.
            List(selection: $selectedCategory) {
                ForEach($categories) { $category in
                    EditableText(text: $category.name)
                        .lineLimit(1)
                        .tag(category.id)
                        .onTapGesture {
                            selectedCategory = category.id
                        }
                }
            }
            .listStyle(SidebarListStyle())
            
            // Bottom buttons now as icon-only.
            HStack {
                Button(action: { isAddingCategory = true }) {
                    Image(systemName: "plus.circle")
                        .foregroundColor(.blue)
                }
                
                Button(action: deleteCategory) {
                    Image(systemName: "minus.circle.fill")
                        .foregroundColor(.red)
                }
            }
            .buttonStyle(BorderlessButtonStyle())
            .padding(.horizontal)
            .padding(.bottom, 8)
            
            if isAddingCategory {
                HStack {
                    TextField("Category name", text: $newCategoryName)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    Button("Add") {
                        if !newCategoryName.isEmpty {
                            categories.append(Category(name: newCategoryName))
                            newCategoryName = ""
                            isAddingCategory = false
                            saveCategories()
                        }
                    }
                    Button("Cancel") {
                        isAddingCategory = false
                        newCategoryName = ""
                    }
                }
                .padding(.horizontal)
                .padding(.bottom, 8)
            }
        }
        .frame(width: 200)
        .background(Color.gray.opacity(0.05))
    }
}

// MARK: - Main Content View

struct MainContentView: View {
    @Binding var categories: [Category]
    @Binding var selectedCategory: UUID?
    @Binding var selectedTab: UUID?
    let currentTabIndex: Int
    @Binding var isAddingTab: Bool
    @Binding var newTabName: String
    
    var body: some View {
        if let categoryIndex = categories.firstIndex(where: { $0.id == selectedCategory }) {
            VStack(alignment: .leading, spacing: 15) {
                TabsView(categories: $categories,
                         categoryIndex: categoryIndex,
                         selectedTab: $selectedTab,
                         isAddingTab: $isAddingTab,
                         newTabName: $newTabName)
                NotesView(categories: $categories, categoryIndex: categoryIndex, currentTabIndex: currentTabIndex)
            }
            .frame(minWidth: 400, minHeight: 400)
            .padding()
        } else {
            Text("Select a category")
                .foregroundColor(.gray)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
    }
}

// MARK: - Tabs View

struct TabsView: View {
    @Binding var categories: [Category]
    let categoryIndex: Int
    @Binding var selectedTab: UUID?
    @Binding var isAddingTab: Bool
    @Binding var newTabName: String
    
    var body: some View {
        VStack(alignment: .leading) {
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 10) {
                    ForEach($categories[categoryIndex].tabs) { $tab in
                        // Use EditableTabView for double-click renaming.
                        EditableTabView(tab: $tab,
                                        isSelected: tab.id == selectedTab,
                                        onSelect: { selectedTab = tab.id })
                    }
                    
                    Button(action: {
                        isAddingTab = true
                    }) {
                        Image(systemName: "plus.circle.fill")
                            .foregroundColor(.blue)
                    }
                    .buttonStyle(BorderlessButtonStyle())
                    
                    // Delete tab button (only if more than one tab exists) now uses red color.
                    if categories[categoryIndex].tabs.count > 1, let currentTabID = selectedTab {
                        Button(action: {
                            if let index = categories[categoryIndex].tabs.firstIndex(where: { $0.id == currentTabID }) {
                                categories[categoryIndex].tabs.remove(at: index)
                                selectedTab = categories[categoryIndex].tabs.first?.id
                            }
                        }) {
                            Image(systemName: "minus.circle.fill")
                                .foregroundColor(.red)
                        }
                        .buttonStyle(BorderlessButtonStyle())
                    }
                }
                .padding(.horizontal)
            }
            .padding(.vertical, 8)
            .background(Color.gray.opacity(0.05))
            .cornerRadius(10)
            
            if isAddingTab {
                HStack {
                    TextField("New Tab Name", text: $newTabName)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    Button("Add") {
                        if !newTabName.isEmpty {
                            categories[categoryIndex].tabs.append(Tab(name: newTabName))
                            selectedTab = categories[categoryIndex].tabs.last?.id
                            newTabName = ""
                            isAddingTab = false
                        }
                    }
                    Button("Cancel") {
                        newTabName = ""
                        isAddingTab = false
                    }
                }
                .padding(.horizontal)
            }
        }
    }
}

// MARK: - Notes View (with Reordering)

struct NotesView: View {
    @Binding var categories: [Category]
    let categoryIndex: Int
    let currentTabIndex: Int
    
    var body: some View {
        // Using a List so that notes are reorderable and deletable.
        List {
            Section(header:
                        HStack {
                Text("Notes")
                    .font(.headline)
                Spacer()
                Button(action: addNote) {
                    Image(systemName: "plus.circle")
                        .foregroundColor(.blue)
                }
            }
            ) {
                // Use enumerated ForEach to supply an onDelete callback for each note.
                ForEach(Array($categories[categoryIndex].tabs[currentTabIndex].notes.enumerated()), id: \.element.id) { index, $note in
                    NoteCardView(note: $note, onDelete: {
                        categories[categoryIndex].tabs[currentTabIndex].notes.remove(at: index)
                    })
                }
                .onMove { indices, newOffset in
                    categories[categoryIndex].tabs[currentTabIndex].notes.move(fromOffsets: indices, toOffset: newOffset)
                }
                .onDelete { indices in
                    categories[categoryIndex].tabs[currentTabIndex].notes.remove(atOffsets: indices)
                }
            }
        }
        .listStyle(PlainListStyle())
    }
    
    // MARK: - Note Functions
    
    private func addNote() {
        categories[categoryIndex].tabs[currentTabIndex].notes.append(Note(content: "", name: "New Note"))
    }
}

// MARK: - EditableTabView

/// A view representing a tab that can be selected by a single tap and renamed via double-tap.
struct EditableTabView: View {
    @Binding var tab: Tab
    let isSelected: Bool
    let onSelect: () -> Void
    @State private var isEditing: Bool = false
    
    var body: some View {
        Group {
            if isEditing {
                TextField("", text: $tab.name, onCommit: {
                    isEditing = false
                })
                .textFieldStyle(RoundedBorderTextFieldStyle())
            } else {
                Text(tab.name)
                    .onTapGesture(count: 2) {
                        isEditing = true
                    }
            }
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 6)
        .background(isSelected ? Color.blue : Color.clear)
        .foregroundColor(isSelected ? .white : .primary)
        .cornerRadius(8)
        .onTapGesture(count: 1) {
            if !isEditing {
                onSelect()
            }
        }
    }
}

// MARK: - Note Card View (with Collapse/Expand, Copy, and Delete)

struct NoteCardView: View {
    @Binding var note: Note
    var onDelete: (() -> Void)? = nil
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Button(action: {
                    note.isExpanded.toggle()   // Toggle the persisted state.
                }) {
                    Image(systemName: note.isExpanded ? "chevron.down" : "chevron.right")
                        .foregroundColor(.blue)
                }
                // Use EditableText for the note title.
                EditableText(text: $note.name)
                    .foregroundColor(.white)
                    .font(.headline)
                Spacer()
                Button(action: {
                    NSPasteboard.general.clearContents()
                    NSPasteboard.general.setString(note.content, forType: .string)
                }) {
                    Image(systemName: "doc.on.doc")
                        .foregroundColor(.blue)
                }
                if let onDelete = onDelete {
                    Button(action: onDelete) {
                        Image(systemName: "trash")
                            .foregroundColor(.red)
                    }
                }
            }
            if note.isExpanded {
                TextEditor(text: $note.content)
                    .padding(.top, 4)
                    .frame(height: 100)
                    .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.gray.opacity(0.5)))
            }
        }
        .padding()
        .background(RoundedRectangle(cornerRadius: 12).fill(Color(white: 0.15)))
        .shadow(radius: 2)
        .contextMenu {
            Button("Copy") {
                NSPasteboard.general.clearContents()
                NSPasteboard.general.setString(note.content, forType: .string)
            }
            if let onDelete = onDelete {
                Button("Delete", role: .destructive, action: onDelete)
            }
        }
    }
}

// MARK: - EditableText

/// A view that shows text which becomes editable (via a TextField) on a double-click.
struct EditableText: View {
    @Binding var text: String
    @State private var isEditing: Bool = false
    
    var body: some View {
        Group {
            if isEditing {
                TextField("", text: $text, onCommit: {
                    isEditing = false
                })
                .textFieldStyle(RoundedBorderTextFieldStyle())
            } else {
                Text(text)
                    .onTapGesture(count: 2) {
                        isEditing = true
                    }
            }
        }
    }
}

// MARK: - Directory Picker

struct DirectoryPicker: View {
    @Binding var isPresented: Bool
    @Binding var directories: [URL]
    
    var body: some View {
        VStack {
            Text("Select a Directory")
                .font(.headline)
                .padding()
            
            Button("Choose Directory") {
                let openPanel = NSOpenPanel()
                openPanel.canChooseDirectories = true
                openPanel.canCreateDirectories = true
                openPanel.canChooseFiles = false
                openPanel.allowsMultipleSelection = false
                
                openPanel.begin { response in
                    if response == .OK, let url = openPanel.url {
                        directories.append(url)
                        isPresented = false
                    }
                }
            }
            .padding()
            
            Button("Cancel") {
                isPresented = false
            }
            .padding()
        }
        .frame(width: 300, height: 200)
    }
}

// MARK: - Settings View

struct SettingsView: View {
    @State private var permissionStatus: String = ""
    
    var body: some View {
        VStack(spacing: 16) {
            Text("Developed by Mitchell Cohen in Newton, MA 2025")
                .multilineTextAlignment(.center)
            
            Button(action: {
                // Recheck the permission and update the status message.
                let granted = recheckAccessibilityPermission()
                permissionStatus = granted ? "Accessibility permission granted." : "Accessibility permission not granted."
            }) {
                ZStack {
                    RoundedRectangle(cornerRadius: 8)
                        .fill(Color.gray)
                        .frame(height: 44)
                    Text("Recheck Permissions")
                        .foregroundColor(.white)
                }
                .frame(maxWidth: .infinity)
            }
            .buttonStyle(PlainButtonStyle())
            
            if !permissionStatus.isEmpty {
                Text(permissionStatus)
                    .font(.caption)
            }
            
            Button(action: {
                exit(0)  // Immediately quit the app.
            }) {
                ZStack {
                    RoundedRectangle(cornerRadius: 8)
                        .fill(Color.blue)
                        .frame(height: 44)
                    Text("Quit")
                        .foregroundColor(.white)
                }
                .frame(maxWidth: .infinity)
            }
            .buttonStyle(PlainButtonStyle())
        }
        .padding()
        .frame(width: 300, height: 200)
    }
}
