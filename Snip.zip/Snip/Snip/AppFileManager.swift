//
//  AppFileManager.swift
//  Snip
//
//  Created by You on [Date].
//

import Foundation

class AppFileManager {
    static let shared = AppFileManager()
    private init() {}
    
    private var appSupportURL: URL? {
        do {
            let urls = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)
            if let url = urls.first {
                let bundleID = Bundle.main.bundleIdentifier ?? "Snip"
                let folderURL = url.appendingPathComponent(bundleID)
                if !FileManager.default.fileExists(atPath: folderURL.path) {
                    try FileManager.default.createDirectory(at: folderURL, withIntermediateDirectories: true, attributes: nil)
                }
                return folderURL
            }
        } catch {
            print("Error creating app support folder: \(error)")
        }
        return nil
    }
    
    private var categoriesFileURL: URL? {
        appSupportURL?.appendingPathComponent("categories.json")
    }
    
    func setupAppSupportFolder() {
        _ = appSupportURL // Force creation of the folder.
    }
    
    func saveCategories(_ categories: [Category]) throws {
        guard let url = categoriesFileURL else { return }
        let encoder = JSONEncoder()
        encoder.outputFormatting = .prettyPrinted
        let data = try encoder.encode(categories)
        try data.write(to: url)
    }
    
    func loadCategories() -> [Category]? {
        guard let url = categoriesFileURL, FileManager.default.fileExists(atPath: url.path) else {
            return nil
        }
        do {
            let data = try Data(contentsOf: url)
            let decoder = JSONDecoder()
            let categories = try decoder.decode([Category].self, from: data)
            return categories
        } catch {
            print("Error loading categories: \(error)")
            return nil
        }
    }
}
